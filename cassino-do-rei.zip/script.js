const simbolos = ["🍉", "💰", "🐯", "🍒", "⭐", "🍇"];

function girar() {
  const slot1 = document.getElementById("slot1");
  const slot2 = document.getElementById("slot2");
  const slot3 = document.getElementById("slot3");
  const resultado = document.getElementById("resultado");

  const s1 = simbolos[Math.floor(Math.random() * simbolos.length)];
  const s2 = simbolos[Math.floor(Math.random() * simbolos.length)];
  const s3 = simbolos[Math.floor(Math.random() * simbolos.length)];

  slot1.textContent = s1;
  slot2.textContent = s2;
  slot3.textContent = s3;

  if (s1 === s2 && s2 === s3) {
    resultado.textContent = "🎉 JACKPOT! Você venceu! 🎉";
    resultado.style.color = "green";
  } else {
    resultado.textContent = "😢 Tente novamente!";
    resultado.style.color = "red";
  }
}